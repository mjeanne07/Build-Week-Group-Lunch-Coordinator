//
//  RestaurantDetailsViewController.swift
//  Group Lunch Coordinator
//
//  Created by SenorLappy on 24/12/19.
//  Copyright © 2019 Morgan Smith. All rights reserved.
//

import UIKit

class RestaurantDetailsViewController: UIViewController {
    var cellRestName: Restaurant?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    func updateViews() {
        
    }
}
