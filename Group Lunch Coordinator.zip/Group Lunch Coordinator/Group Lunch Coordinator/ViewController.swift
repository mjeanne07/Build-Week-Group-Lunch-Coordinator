//
//  ViewController.swift
//  Group Lunch Coordinator
//
//  Created by Morgan Smith on 12/17/19.
//  Copyright © 2019 Morgan Smith. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

